package com.example.cadastrousuario;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;

public class MainActivity extends AppCompatActivity {
    CharSequence[] items = {"Administrador", "Terceiro"};
    boolean[] itemsChecked = new boolean[items.length];
    String tag = "Events";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //--oculta a barra de titulo--
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_main);

        Log.d(tag, "No evento onCreate()");
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {
            starActivity(new Intent("com.example.ACTIVITY2"));
        }
        return false;
    }

    public void onStart() {
        super.onStart();
        Log.d(tag, "No onStart()");
    }

    public void Restart() {
        super.onRestart();
        Log.d(tag, "No evento onRestart()");
    }

    public void onResume() {
        super.onResume();
        Log.d(tag, "No evento onResume()");
    }

    public void onPause() {
        super.onPause();
        Log.d(tag, "No evento onPause()");
    }

    public void onStop() {
        super.onStop();
        Log.d(tag, "No evento onStop()");
    }

    public void onDestroy() {
        super.onDestroy();
        Log.d(tag, "No evento onDestroy()");
    }
}


