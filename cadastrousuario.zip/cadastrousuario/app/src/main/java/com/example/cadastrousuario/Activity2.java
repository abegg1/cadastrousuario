package com.example.cadastrousuario;

import android.app.Activity;
import android.os.Bundle;

public class Activity2 extends Activity {
    @Override
    public void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity2);
        )
    }

}